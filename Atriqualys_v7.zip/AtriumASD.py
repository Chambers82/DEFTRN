# Programmer: Brent Chambers
# Date: February 4, 2016
# Filename: AtriumTEST.py
# Technique: Fast Indexing of ATRIUM ASD Inventory Files
# Syntax:
# Description: Library for Fast Indexing of ATRIUM ASD Inventory Files

import time

import xlrd
import xlwt
import sets
import string
import AtriumSTATS
from operator import itemgetter
from datetime import datetime

def get_datestamp():
	now = string.split(time.ctime())
	year   = now[-1]
	month  = now[1]
	day    = now[0]
	date   = now[2]
	creationStamp = year+"_"+month+"_"+day+"_"+date
	return creationStamp

def convert2string(ip_list):
        ips = ''
        for host in ip_list:
                ips += host + ', '
        ips = ips[:-1]
        return ips

def extractIPs(recordList):
        collect = []
        for item in recordList:
                collect.append(item[20])
        #print "Record count: ", len(recordList)
        #print "IP count:     ", len(collect)
        return collect



class ASD:
	filename = ''
	cache = ''
	book = ''
	creationStamp = ''
	Fields = {}
	RecordIndex = {}			#Field:[]
	start = 0
	stop = 0
	retail_host_list =[]
	retail_host_list_prod = []
	retail_host_list_nonprod = []
	pbm_host_list = []
	pbm_host_list_prod = []
	pbm_host_list_nonprod = []
	
	
	
	def __init__(self, filename="Atrium ASD Application Information 2-11-16.xlsx"):
                self.filename = filename
		self.creationStamp = get_datestamp()
		self.book = xlrd.open_workbook(self.filename)
		print "\nPopulating Atrium ASD Application fields..."
		self.populateFields()
		print "\nCreating records..."
		self.createRecordIndex()
		print "Populating records..."
		self.populateRecordIndex()
		print "Organizing sites..."
		self.organizeBySite()
		self.defineRange()

				
	def defineRange(self):
		self.start = int(self.Fields.keys()[0])
		self.stop = int(self.Fields.keys()[-1])
				
	
	def populateFields(self):
		sheet = self.book.sheet_by_name("Export Worksheet")
		# Get the column titles from the page
		for i in range(0, 50):
			try:
				self.Fields[i]= sheet.cell(1,i).__str__()[7:-1] 		# because the cell object has a type lable (e.g 'text:')
			except:
				pass
		for item in self.Fields.values():
			print item
			
	def createRecordIndex(self):
		for item in self.Fields.values():
			self.RecordIndex[item] = []
	
	def populateRecordIndex(self):
		sheet = self.book.sheet_by_name("Export Worksheet")
		start = int(self.Fields.keys()[0])
		stop = int(self.Fields.keys()[-1]+1)
		print start, stop
		for column in range(start, stop):
			self.RecordIndex[self.Fields.keys()[column]] = sheet.col_values(column)

		
	def checkRecordImport(self):
		for column in range(int(self.start), int(self.stop)):
			print self.RecordIndex.keys()[column]#,":     ", len(self.RecordIndex[self.Fields[column]])
	
	# Data Retrival -- 
		
	def returnRecord(self, recordIndexVal):
		sheet = self.book.sheet_by_name("Export Worksheet")
		start = int(self.Fields.keys()[0])
		stop = int(self.Fields.keys()[-1]+1)		
		record = []
		for field in range(start, stop):
			record.append(self.RecordIndex[self.Fields.keys()[field]][recordIndexVal])
		# Run a len calculation to ensure all 
		return record

	def searchServers(self, query):
		masterResults = []
		searchResults = []
		searchServerResults = []
		serverSearchResults = []
		serverSearchResults = [ t for t in self.RecordIndex[15] if query in t ]

		for server in serverSearchResults:
				indexVal = self.RecordIndex[15].index(server)
				searchResults.append(self.returnRecord(indexVal))
		return searchResults


	def returnFieldfromRef(self, indexRef):
			try:
					#collect = self.RecordIndex[indexRef]            #grab the list
					name = self.Fields[indexRef]
			except:
					print "Could not find record, or record does not exist."
			return name

	def returnFieldRecords(self, indexRef, query):
			masterResults = []
			searchResults = []
			searchServerResults = []
			# Get the index number from the RecordIndex
			for item in self.RecordIndex[indexRef]:
					upperCaseValue = string.upper(item)
					splitCategory = string.split(upperCaseValue, " ")
					if string.upper(query) in splitCategory:
							searchResults.append(self.RecordIndex[indexRef].index(item))
			for item in searchResults:
					masterResults.append(self.returnRecord(item))
			return masterResults


	def organizeBySite(self):
		searchResults = []
		counter = int(0)
		for item in self.RecordIndex[19]:
			serverSite = string.split(item, " ")
			if "(DC)" in serverSite:
				self.retail_host_list.append(self.returnRecord(counter))
			elif "(DC" in serverSite:
				self.retail_host_list.append(self.returnRecord(counter))
			elif "(DC-" in serverSite:
				self.retail_host_list.append(self.returnRecord(counter))
			elif "CVS" and "Drive" in serverSite:
				self.retail_host_list.append(self.returnRecord(counter))
			elif "RI" and "2100" in serverSite:
				self.retail_host_list.append(self.returnRecord(counter))
			else:
				self.pbm_host_list.append(self.returnRecord(counter))
				counter = counter + 1

		print "Parsing production retail hosts..."
		for item in self.retail_host_list:
			if item[2] == "Production":
				self.retail_host_list_prod.append(item)
			else:
				self.retail_host_list_nonprod.append(item)

		print "Parsing production pbm hosts..."
		for item in self.pbm_host_list:
			if item[2] == "Production":
				self.pbm_host_list_prod.append(item)
			else:
				self.pbm_host_list_nonprod.append(item)


		print "*************** Checks ******************"
		print "Retail Hosts Indexed:             " + str( len(self.retail_host_list))
		print "------------------------------------------"
		print "Retail - Production hosts:        " + str(len(self.retail_host_list_prod))
		print "Retail - Non-production hosts :   " + str(len(self.retail_host_list_nonprod))
		print "------------------------------------------"

		if str(len(self.retail_host_list_prod) + len(self.retail_host_list_nonprod)) == str( len(self.retail_host_list)):
			print "                Check Totals:     " + str(len(self.retail_host_list_prod) + len(self.retail_host_list_nonprod)) + " [GOOD]"
		else:
			print "                Check Totals:     " + str(len(self.retail_host_list_prod) + len(self.retail_host_list_nonprod)) + "INCONSISTENT"

		print "\n"
		print "PBM Hosts Indexed:                " + str(len(self.pbm_host_list))
		print "------------------------------------------"
		print "PBM - Production hosts:           " + str(len(self.pbm_host_list_prod))
		print "PBM - Non-production hosts:       " + str(len(self.pbm_host_list_nonprod))
		print "------------------------------------------"

		if str(len(self.pbm_host_list_prod) + len(self.pbm_host_list_nonprod)) == str(len(self.pbm_host_list)):
			print "                    Check Totals: " + str(len(self.pbm_host_list_prod) + len(self.pbm_host_list_nonprod)) + " [GOOD]"
		else:
			print "                    Check Totals: " + str(len(self.pbm_host_list_prod) + len(self.pbm_host_list_nonprod)) + "INCONSISTENT"
			
		print "\n"
		print "Consistency Check:"
		print "------------------------------------------"
		print "Total hosts indexed (RETAIL + PBM):   " + str(len(self.retail_host_list)+len(self.pbm_host_list))
		print "Compared to all records indexed:      " + str(len(self.RecordIndex[0]))
		print "\n\n"
