# Programmer: Brent Chambers
# Date: February 18, 2016
# Filename: agupdate.py
# Technique: Creating Dynamic Asset Groups from Atrium
# Syntax: agupdate.py AtriumASD.xlsx
# Description:  Qualys Asset Group update utility.
# Purpose
'''
The final, streamlined product will be a simple command line tool that
will take an AtriumASD.xls file as an argument and execute an update
retail|pbm or an update_all.
'''

import sys
from sets import Set
import AtriumASD
import QualysAccess

def extractIPs(recordList):
        ip_collect = []
        for item in recordList:
                ip_collect.append(item[20])
        unique_collect = []
        for item in Set(ip_collect):
                unique_collect.append(item)
        #print "Collected IP count: ", len(ip_collect)
        #print "Unique IP count:    ", len(unique_collect)
        return unique_collect

# Create instances of both classes
try:
    atrium = AtriumASD.ASD(sys.argv[1])
except:
    atrium = AtriumASD.ASD()
qualys = QualysAccess.Assets()

print "Parsed results from file:"
print "-------------------------"
print "Retail hosts:                        ", len(atrium.retail_host_list)
print "Retail production records:           ", len(atrium.retail_host_list_prod)
print "Unique retail production hosts:      ", len(extractIPs(atrium.retail_host_list_prod))
print "Retail nonproduction hosts:          ", len(atrium.retail_host_list_nonprod)
print "Unique retail nonproducation hosts:  ", len(extractIPs(atrium.retail_host_list_nonprod))
print
print "PBM hosts:                           ", len(atrium.pbm_host_list)
print "PBM production hosts:                ", len(atrium.pbm_host_list_prod)
print "Unique PBM productions hosts:        ", len(extractIPs(atrium.pbm_host_list_prod))
print "PBM nonproduction hosts:             ", len(atrium.pbm_host_list_nonprod)
print "Unique PBM nonproduction hosts:      ", len(extractIPs(atrium.pbm_host_list_nonprod))


'''
import qualysapi, sys
from lxml import objectify
# Connect to QualysGuard.
qgc = qualysapi.connect()
# Capture number of days from command parameter.
number_of_days = sys.argv[1]
# Request assets older than number_of_days.
assets = qgc.request('asset_search.php', {'last_scan': 'not_within:%s' % number_of_days, 'target_asset_groups': 'All'})
root = objectify.fromstring(assets)
# Parse assets XML for list of IPs.
ips = ''
for host in root.HOST_LIST.HOST:
    for ip in host.IP:
        ips += ip.text + ','
ips = ips[:-1]
# Purge assets older than number_of_days.
print ips
purge = qgc.request('/api/2.0/fo/asset/host/', {'action': 'purge', 'ips': ips})
print purge
'''












#if __name__ == '__main__':
    



