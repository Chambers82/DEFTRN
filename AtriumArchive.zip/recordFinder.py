# Record Finder


import xlwt
import xlrd

def returnNewRow():

    book = xlrd.open_workbook("c:\\Python27\\Qualys\\AtriumTracker.xls")
    sheet = book.sheet_by_name("A Test Sheet")
    newRow = ''
    for i in range(1,365):
        try:
            print sheet.cell(2, i).__str__()
        except:
            newRow = i
            return newRow

 
            
def populateRecord(statlist):
    font0 = xlwt.Font()
    font0.name = "Times New Roman"
    font0.color_index = 2
    font0.bold = True
    style0 = xlwt.XFStyle()
    style0.font = font0
    style1 = xlwt.XFStyle()
    style0.num_format_str = 'D-MMM-YY'    
    column = returnNewRow()
    row = 3

    # Create timestamp field entry
    sheet.write(column, row, datetime.now(), style0)
    for item in statlist:
        sheet.write(row, column, item[0])
        row = row + 1
    
    
    # for each item in key/val,
        #populate cell(row, column, item[1])
