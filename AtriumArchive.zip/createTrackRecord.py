import sets
import xlwt
from datetime import datetime
from operator import itemgetter

font0 = xlwt.Font()
font0.name = "Times New Roman"
font0.color_index = 2
font0.bold = True

style0 = xlwt.XFStyle()
style0.font = font0

style1 = xlwt.XFStyle()
style0.num_format_str = 'D-MMM-YY'

wb = xlwt.Workbook()
ws = wb.add_sheet('A Test Sheet')

def createStatisticSnapshot():
	ws.write(0, 0, 'Atrium Asset Tracker v1.0', style0)
	ws.write(1, 1, datetime.now(), style0)
	recordNum = 2
	for item in newList:
		ws.write(recordNum, 0, item[0])		#key	
		ws.write(recordNum, 1, item[1])		#val
	ws.write(2, 2, xlwt.Formula("A3+B3"))

wb.save('AtriumTracker.xls')
